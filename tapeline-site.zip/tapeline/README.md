# Tapeline

A song and release studio. `index.html` is a complete static website: no build step, no server.

## Put it online (free, about 2 minutes)
- **Netlify:** drag this folder onto app.netlify.com/drop.
- **GitHub Pages:** push the folder to a repo, then Settings > Pages > deploy from main.
- **Vercel / Cloudflare Pages:** import the repo, no build command, output directory `.`

## What is stored where
Everything (account, songs, releases, covers) is saved in each visitor's browser (localStorage). Audio files are kept for the session only. Release page links only open in the browser that created them.

## Turning it into a real multi-user site
Needs a backend. Build order that fits the original plan:
1. Node/Express + PostgreSQL (Prisma) with the schema from the plan
2. Discord OAuth2 ("Sign in with Discord") replacing the username box
3. S3-compatible storage with presigned uploads for audio and cover art
4. FFmpeg worker for waveforms and previews
5. Public release pages served from the database
6. Distributor adapters
